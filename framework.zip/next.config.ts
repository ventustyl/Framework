import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  reactStrictMode: true,
  basePath: "/react",
  assetPrefix: "/react/",
};

export default nextConfig;

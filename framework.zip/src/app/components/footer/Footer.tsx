import style from './Footer.module.css'

export default function Footer() {
  return <div className={style.footer}>Footer</div>;
}

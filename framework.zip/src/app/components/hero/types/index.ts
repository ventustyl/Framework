export type HeroFunction = {
  name: string;
  color: string;
};
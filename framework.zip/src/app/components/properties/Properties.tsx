"use client";

import React, { useEffect, useRef } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/dist/ScrollTrigger";
import styles from "./Properties.module.css";

const REACT_CONCEPTS = [
  {
    id: "jsx",
    text: "JSX",
    title:
      "Définition : Une syntaxe qui permet d'écrire du HTML directement dans JavaScript. Elle rend le code React plus lisible.",
    exemple: "const App = () => <h1>Hello, JSX!</h1>;",
  },
  {
    id: "vdom",
    text: "Virtual DOM",
    title:
      "Définition : Une représentation légère du DOM réel utilisée par React pour calculer les changements avant de les appliquer au DOM réel.",
    exemple:
      "// Concept : React met à jour uniquement les parties modifiées dans le DOM réel.",
  },
  {
    id: "components",
    text: "Composants",
    title:
      "Définition : Des blocs réutilisables de code React qui encapsulent des morceaux d'interface utilisateur.",
    exemple: "const Button = () => <button>Click me</button>;",
  },
  {
    id: "props",
    text: "Propriétés",
    title:
      "Définition : Les données transmises d'un composant parent à un composant enfant.",
    exemple: "const Greeting = ({ name }) => <h1>Hello, {name}!</h1>;",
  },
  {
    id: "state",
    text: "État",
    title:
      "Définition : Un objet géré par React pour stocker des données dynamiques au sein d'un composant.",
    exemple:
      "import { useState } from 'react';\nconst Counter = () => {\n  const [count, setCount] = useState(0);\n  return <button onClick={() => setCount(count + 1)}>Count: {count}</button>;\n};",
  },
  {
    id: "context",
    text: "Contexte",
    title:
      "Définition : Une manière de partager des données (ex. : thème, langue) à travers l'arbre de composants sans passer par des props.",
    exemple:
      "import { createContext, useContext } from 'react';\nconst ThemeContext = createContext('light');\nconst App = () => (\n  <ThemeContext.Provider value='dark'>\n    <Child />\n  </ThemeContext.Provider>\n);\nconst Child = () => {\n  const theme = useContext(ThemeContext);\n  return <p>Theme: {theme}</p>;\n};",
  },
  {
    id: "hooks",
    text: "Hooks",
    title:
      "Définition : Des fonctions spéciales qui permettent d'utiliser des fonctionnalités comme l’état et le cycle de vie dans des composants fonctionnels.",
    exemple:
      "import { useState } from 'react';\nconst Counter = () => {\n  const [count, setCount] = useState(0);\n  return <button onClick={() => setCount(count + 1)}>Count: {count}</button>;\n};",
  },
  {
    id: "portal",
    text: "Portail",
    title:
      "Définition : Permet de rendre un composant dans un DOM différent de celui de son parent.",
    exemple:
      "import ReactDOM from 'react-dom';\nconst Modal = () => ReactDOM.createPortal(\n  <div>Modal Content</div>,\n  document.getElementById('modal-root')\n);",
  },
  {
    id: "ref",
    text: "Ref",
    title:
      "Définition : Une référence pour accéder directement à un élément DOM ou un composant.",
    exemple:
      "import { useRef } from 'react';\nconst InputFocus = () => {\n  const inputRef = useRef();\n  return (\n    <div>\n      <input ref={inputRef} />\n      <button onClick={() => inputRef.current.focus()}>Focus Input</button>\n    </div>\n  );\n};",
  },
  {
    id: "render-props",
    text: "Render Props",
    title:
      "Définition : Un pattern où une fonction est utilisée comme prop pour contrôler ce qu’un composant rend.",
    exemple:
      "const Mouse = ({ render }) => {\n  const [x, y] = [100, 200]; // Simulé\n  return render({ x, y });\n};\nconst App = () => (\n  <Mouse render={({ x, y }) => <p>Mouse position: {x}, {y}</p>} />\n);",
  },
  {
    id: "hoc",
    text: "Higher-Order Components",
    title:
      "Définition : Une fonction qui prend un composant et retourne un nouveau composant avec des fonctionnalités ajoutées.",
    exemple:
      "const withGreeting = (Component) => (props) =>\n  <div><Component {...props} /> Welcome!</div>;\nconst App = () => <p>Hello</p>;\nconst EnhancedApp = withGreeting(App);",
  },
  {
    id: "lazy",
    text: "Lazy Loading",
    title:
      "Définition : Charger des composants ou des parties d'application uniquement lorsque nécessaire.",
    exemple:
      "import React, { lazy, Suspense } from 'react';\nconst LazyComponent = lazy(() => import('./MyComponent'));\nconst App = () => (\n  <Suspense fallback={<p>Loading...</p>}>\n    <LazyComponent />\n  </Suspense>\n);",
  },
  {
    id: "suspense",
    text: "Suspense",
    title:
      "Définition : Un composant utilisé pour afficher un état de chargement pendant que d’autres composants se chargent.",
    exemple:
      "<Suspense fallback={<p>Loading...</p>}>\n  <LazyComponent />\n</Suspense>",
  },
  {
    id: "router",
    text: "React Router",
    title:
      "Définition : Une bibliothèque pour gérer les routes dans une application React.",
    exemple:
      "import { BrowserRouter, Routes, Route } from 'react-router-dom';\nconst App = () => (\n  <BrowserRouter>\n    <Routes>\n      <Route path='/' element={<Home />} />\n      <Route path='/about' element={<About />} />\n    </Routes>\n  </BrowserRouter>\n);",
  },
];

const Properties = () => {
  const scrollerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    gsap.registerPlugin(ScrollTrigger);

    const setupAnimations = () => {
      const panels = gsap.utils.toArray(`.${styles.panel}`) as HTMLElement[];
      const texts = gsap.utils.toArray(`.${styles.panelText}`) as HTMLElement[];

      // Set initial z-indexes
      gsap.set([`.${styles.panel}`, `.${styles.panelText}`], {
        zIndex: (i, _, targets) => targets.length - i,
      });

      // Animate panels
      panels.forEach((panel, i) => {
        gsap
          .timeline({
            scrollTrigger: {
              trigger: `.${styles.black}`,
              start: () => `top -${window.innerHeight * (i + 0.5)}`,
              end: () => `+=${window.innerHeight}`,
              scrub: true,
              invalidateOnRefresh: true,
            },
          })
          .to(panel, { height: 60 });
      });

      // Animate texts
      texts.forEach((text, i) => {
        gsap
          .timeline({
            scrollTrigger: {
              trigger: `.${styles.black}`,
              start: () => `top -${window.innerHeight * i}`,
              end: () => `+=${window.innerHeight}`,
              scrub: true,
              invalidateOnRefresh: true,
            },
          })
          .to(text, {
            duration: 0.33,
            opacity: 1,
            y: "90%",
          })
          .to(
            text,
            {
              duration: 0.33,
              opacity: 0,
              y: "0%",
            },
            0.66
          );
      });

      // Pin section
      ScrollTrigger.create({
        trigger: `.${styles.black}`,
        scrub: true,
        pin: true,
        start: "top top",
        end: () => `+=${(panels.length + 1) * window.innerHeight}`,
        invalidateOnRefresh: true,
      });
    };

    setupAnimations();

    return () => {
      ScrollTrigger.getAll().forEach((trigger) => trigger.kill());
    };
  }, []);

  return (
    <div className={styles.scroller} ref={scrollerRef} id="properties">
      <section className={styles.orange}>
        <div className={styles.text}>
          Découvrez les concepts fondamentaux de React
        </div>
      </section>

      <section className={styles.black}>
        <div className={styles.textWrap}>
          {REACT_CONCEPTS.map((concept) => (
            <div key={concept.id} className={styles.panelText}>
              {concept.text}
            </div>
          ))}
        </div>

        <div className={styles.pWrap}>
          {REACT_CONCEPTS.map((concept) => (
            <div key={concept.id} className={styles.panel} />
          ))}
        </div>
      </section>

      <section className={styles.blue} />
    </div>
  );
};

export default Properties;
